import os
import hashlib
import hmac
from typing import Tuple, Optional

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend


class CryptoEngine:
    NONCE_SIZE = 12
    TAG_SIZE = 16
    KEY_SIZE = 32
    
    def __init__(self, shared_secret: bytes, salt: Optional[bytes] = None):
        self._salt = salt or os.urandom(16)
        self._key = self._derive_key(shared_secret, self._salt)
        self._aesgcm = AESGCM(self._key)
    
    def _derive_key(self, secret: bytes, salt: bytes) -> bytes:
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=self.KEY_SIZE,
            salt=salt,
            info=b"eni-c2-v1.0",
            backend=default_backend()
        )
        return hkdf.derive(secret)
    
    def encrypt(self, plaintext: bytes, aad: Optional[bytes] = None) -> Tuple[bytes, bytes, bytes]:
        nonce = os.urandom(12)  # <-- CAMBIADO A ALEATORIO
        ct = self._aesgcm.encrypt(nonce, plaintext, aad)
        return ct, nonce, self._salt
    
    def decrypt(self, ciphertext: bytes, nonce: bytes, aad: Optional[bytes] = None) -> bytes:
        return self._aesgcm.decrypt(nonce, ciphertext, aad)
    
    @staticmethod
    def generate_secret() -> bytes:
        return os.urandom(32)
    
    @staticmethod
    def hmac_verify(key: bytes, message: bytes, signature: bytes) -> bool:
        expected = hmac.new(key, message, hashlib.sha256).digest()
        return hmac.compare_digest(expected, signature)