"""
ENI-C2 Protocol
"""

import json
import base64
import time
import uuid
import logging
from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, Any

from .crypto import CryptoEngine

logging.basicConfig(level=logging.DEBUG)
log = logging.getLogger("ENI-Protocol")

class MessageType(Enum):
    CHECKIN = "checkin"
    HEARTBEAT = "heartbeat"
    TASK = "task"
    RESULT = "result"
    ERROR = "error"
    FILE_UPLOAD = "file_upload"
    FILE_DOWNLOAD = "file_download"
    STEALTH = "stealth"

@dataclass
class C2Message:
    type: MessageType
    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: float = field(default_factory=time.time)
    payload: Dict[str, Any] = field(default_factory=dict)
    nonce: Optional[bytes] = None
    tag: Optional[bytes] = None
    
    def to_dict(self) -> dict:
        d = asdict(self)
        d["type"] = self.type.value
        if self.nonce:
            d["nonce"] = base64.b64encode(self.nonce).decode()
        if self.tag:
            d["tag"] = base64.b64encode(self.tag).decode()
        return d
    
    @classmethod
    def from_dict(cls, data: dict) -> "C2Message":
        data["type"] = MessageType(data["type"])
        if data.get("nonce"):
            data["nonce"] = base64.b64decode(data["nonce"])
        if data.get("tag"):
            data["tag"] = base64.b64decode(data["tag"])
        return cls(**data)

class ProtocolHandler:
    def __init__(self, crypto: CryptoEngine, shared_secret: bytes):
        self.crypto = crypto
        self.shared_secret = shared_secret
        log.info(f"ProtocolHandler inicializado")
    
    def encode(self, msg: C2Message) -> str:
        log.info(f"📤 Codificando mensaje tipo: {msg.type}")
        raw = json.dumps(msg.to_dict()).encode()
        log.info(f"📤 Raw JSON: {raw[:100]}...")
        ct, nonce, salt = self.crypto.encrypt(raw)
        log.info(f"📤 Encrypted size: {len(ct)} bytes")
        transport = {
            "data": base64.b64encode(ct).decode(),
            "nonce": base64.b64encode(nonce).decode(),
            "salt": base64.b64encode(salt).decode(),
        }
        result = json.dumps(transport)
        log.info(f"📤 Transport length: {len(result)} chars")
        return result
    
    def decode(self, transport_str: str) -> C2Message:
        log.info(f"📥 Decodificando mensaje de {len(transport_str)} caracteres")
        try:
            log.info(f"📥 Intentando parsear JSON...")
            transport = json.loads(transport_str)
            log.info(f"📥 JSON parseado: keys={list(transport.keys())}")
            
            log.info(f"📥 Decodificando data...")
            ct = base64.b64decode(transport["data"])
            log.info(f"📥 Data length: {len(ct)} bytes")
            
            log.info(f"📥 Decodificando nonce...")
            nonce = base64.b64decode(transport["nonce"])
            log.info(f"📥 Nonce length: {len(nonce)} bytes")
            
            log.info(f"📥 Decodificando salt...")
            salt = base64.b64decode(transport["salt"])
            log.info(f"📥 Salt length: {len(salt)} bytes")
            
            log.info(f"📥 Creando CryptoEngine con salt...")
            temp_crypto = CryptoEngine(self.shared_secret, salt)
            
            log.info(f"📥 Intentando descifrar...")
            raw = temp_crypto.decrypt(ct, nonce)
            log.info(f"📥 Descifrado: {len(raw)} bytes")
            
            log.info(f"📥 Parseando JSON final...")
            data = json.loads(raw)
            log.info(f"📥 Datos: {str(data)[:200]}...")
            
            msg = C2Message.from_dict(data)
            log.info(f"✅ Mensaje decodificado correctamente")
            return msg
            
        except json.JSONDecodeError as e:
            log.error(f"❌ Error JSON: {e}")
            raise ValueError(f"JSON decode error: {e}")
        except Exception as e:
            log.error(f"❌ Error en decode: {e}")
            log.error(f"❌ Traceback: {traceback.format_exc()}")
            raise ValueError(f"Failed to decode: {e}")